package com.example.demo;

import javax.xml.crypto.Data;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class userin {
    @Id
    
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    int id;
  String name;
  String email;
  String phnum;
  String password;
  String repassword;

  public int getId() {
    return id;
  }
  public void setId(int id) {
    this.id = id;
  }
  public String getName() {
    return name;
  }
  
  public void setName(String name) {
    this.name = name;
  }
  public String getEmail() {
    return email;
  }
  public void setEmail(String email) {
    this.email = email;
  }
  public String getPhnum() {
    return phnum;
  }
  public void setPhnum(String phnum) {
    this.phnum = phnum;
  }
  public String getPassword() {
    return password;
  }
  public void setPassword(String password) {
    this.password = password;
  }
//  public String getRepassword() {
//    return repassword;
//  }
//  public void setRepassword(String repassword) {
//    this.repassword = repassword;
//  }
    public Data orElse(Object object) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'orElse'");
    }
  
}