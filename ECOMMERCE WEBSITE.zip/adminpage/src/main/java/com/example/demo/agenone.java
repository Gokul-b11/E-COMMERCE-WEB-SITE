package com.example.demo;



import org.springframework.data.repository.CrudRepository;

public interface agenone extends CrudRepository<userin, Integer> {
	 userin findByEmail(String email);
	 
	

}
