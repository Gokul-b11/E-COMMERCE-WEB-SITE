package com.example.demo;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class adminctrl {

    @Autowired
    private agent a;
    @Autowired
    staffloginagent sa;

    @RequestMapping("/")
    public String main() {
        return "main";
    }

    @RequestMapping("home")
    public String home() {
        return "home";
    }
    // @RequestMapping("mhome")
    // public String homeemy() {
    //     return "mhome";
    // }

    @RequestMapping("/products")
    public String products(Model model) {
        List<productsentity> items = (List<productsentity>) a.findAll();
        model.addAttribute("items", items);
        return "productpage"; // Change if needed
    }

    @RequestMapping("productpage")
    public String all(Model model) {
        List<productsentity> items = (List<productsentity>) a.findAll();
        model.addAttribute("items", items);
        return "productpage";
    }

    @RequestMapping("displays")
    public String nexts(@RequestParam String name,
            @RequestParam String des,
            @RequestParam String category,
            @RequestParam LocalDate startDate,
            @RequestParam Double oldprize,
            @RequestParam int discount, MultipartFile file, Model m) throws IOException {

        File directory = new File("C:/uploads");
        if (!directory.exists()) {
            directory.mkdirs();
        }
        String fileName = file.getOriginalFilename();
        File targetFile = new File(directory, fileName);
        file.transferTo(targetFile);

        productsentity p = new productsentity();
        p.setName(name);
        p.setDes(des);
        p.setCategory(category);
        p.setStartDate(startDate);

        // Expiration date is 7 days from start date
        p.setExpDate(startDate.plusDays(7));
        p.setOldprize(oldprize);

        double dis = (oldprize * discount / 100);
        Double newprize = oldprize - dis;
        p.setDiscount(discount);
        p.setNewprize(newprize);
        p.setFilepath("/uploads/" + fileName);

        a.save(p);
        m.addAttribute("msg", "Product Added!!");
        return "addproduct";
    }

    @RequestMapping("addproduct")

    String next() {

        return "addproduct";
    }

    @RequestMapping("category")
    String find() {

        return "category";

    }

    @RequestMapping("findbynamecontaining")
    String aallss(@RequestParam String category, Model m) {
        List<productsentity> items = (List<productsentity>) a.findByCategoryContaining(category);
        m.addAttribute("items", items);
        return "productpage";

    }

    @RequestMapping("staffdata")
    String staffdetails(Model m) {
        List<stafflogin> items = (List<stafflogin>) sa.findAll();
        m.addAttribute("items", items);
        return "staffdata";
    }

    // vendor_________________________________________________

    @Autowired
    javai v;

    @RequestMapping("vendors")
    String vendors() {
        return "vendors";
    }

    @RequestMapping("vendor_login")
    String vender_login() {
        return "vendors_login";
    }

    @RequestMapping("productss")
    String product() {
        return "products";
    }

    @RequestMapping("sadd")
    String sadd(@RequestParam String name, String mail, String pass, Model m) {
        vtab s = new vtab();
        s.setName(name);
        s.setMail(mail);
        s.setPass(pass);
        v.save(s);
        m.addAttribute("msg", "Value Upadated");
        return "vendors_login";
    }

    @RequestMapping("vendorsdetails")
    String vendordetails(Model model) {
        List<vtab> items = (List<vtab>) v.findAll();
        model.addAttribute("items", items);
        return "vendorsdetails";
    }

    @RequestMapping("vendors_login")
    String log(@RequestParam String name, String pass, Model m) {
        vtab s = v.findByName(name);
        if (s.getPass().equals(pass)) {
            m.addAttribute("user", s);
            return "vendors_board";
        } else {
            m.addAttribute("msg", "your login detail is worng");
            return "vendor_login";
        }
    }

    @GetMapping("/vendor_product/{name}")
    public String V_products(@PathVariable("name") String name, Model model) {
        List<productsentity> items = a.findByCategory(name);
        model.addAttribute("items", items);
        return "productpage"; // Ensure this exists
    }

    // staff_________________________________________________

    @Autowired
    agent_three c;

    @RequestMapping("addstaffs")
    String addstaffs() {
        return "addstaff";
    }

    @RequestMapping("as")
    String add(@RequestParam int id, String username, String email, String password, Model m) {
        staftable e = new staftable();
        e.setId(id);
        e.setUsername(username);
        e.setEmail(email);
        e.setPassword(password);
        c.save(e);

        m.addAttribute("msg", "Staff Sucessfully Added");
        return "addstaff";
    }

    @RequestMapping("staffdetails")
    String staffs(Model m) {
        List<staftable> items = (List<staftable>) c.findAll();
        m.addAttribute("items", items);
        return "view_staff";
    }
    // user_________________________________________________

    @Autowired
    agenone ao;

    @RequestMapping("signup")
    String signup() {
        return "signup";
    }

    @RequestMapping("/add")
    String add(@RequestParam String name, String email, String phnum, String password) {
        userin t = new userin();
        t.setName(name);
        t.setEmail(email);
        t.setPhnum(phnum);
        t.setPassword(password);
        ao.save(t);
        return "login";
    }

    @RequestMapping("login")
    String login() {
        return "login";
    }

    @RequestMapping("/log")
    String logs(@RequestParam String email, String password, Model m) {

        System.out.println("");
        userin e = (userin) ao.findByEmail(email);

        if (e.getPassword().equals(password)) {
            List<productsentity> items = (List<productsentity>) a.findAll();
            m.addAttribute("all", items);

            m.addAttribute("user", e);
            return "mhome";
        } else {
            m.addAttribute("msg", "Your login details is Worng");
            return "login";
        }
    }

    @RequestMapping("userdetails")
    String userDetailss(Model model) {
        List<userin> items = (List<userin>) ao.findAll();
        model.addAttribute("items", items);
        return "userdetails";
    }

    @RequestMapping("findbymail")
    String Find() {
        return "findbymail";
    }

    @RequestMapping("mail")
    String mail(@RequestParam String email, Model m) {
        List<userin> items = (List<userin>) ao.findByEmail(email);
        m.addAttribute("items", items);
        return "userdetails";

    }

    String mhome(Model m) {
        List<productsentity> items = (List<productsentity>) a.findAll();
        m.addAttribute("items", items);
        return "productpage"; // Change if needed
    }


    //-----addtocart--

    @Autowired
    addi cd;

    @GetMapping("/addtocart/{cid}/{pid}")
    String addtocart(@PathVariable("cid") int cid, @PathVariable("pid") long pid ,Model m)
    {
    
        productsentity p=a.findById(pid);
        userin e =ao.findById(cid).orElse(null);
        addtocard ad=new addtocard();


        ad.setCid(cid);
        ad.setPid(pid);
        ad.setName(p.name);
        ad.setCategory(p.category);
        ad.setOldprize(p.oldprize);
        ad.setNewprize(p.newprize);
        ad.setDiscount(p.discount);
        cd.save(ad);
        List<productsentity> items = (List<productsentity>) a.findAll();
        m.addAttribute("all", items);

        m.addAttribute("user", e);
        return "mhome";
    }

    @GetMapping("/mycard/{cid}")

    String mycart(@PathVariable("cid") int cid,Model m)
    {
        m.addAttribute("items", cd.findByCid(cid));
        return "mycard";
    }





}