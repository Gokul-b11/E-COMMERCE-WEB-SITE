package com.example.demo;

import org.springframework.data.repository.CrudRepository;

public interface javai extends CrudRepository<vtab, String> {
        vtab findByName(String name);

}
