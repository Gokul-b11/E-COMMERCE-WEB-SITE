package com.example.demo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

public interface agenone extends CrudRepository<userin, Integer> {
	 userin findByEmail(String email);
	 
	

}
