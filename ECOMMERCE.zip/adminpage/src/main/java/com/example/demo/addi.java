package com.example.demo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;



public interface addi extends CrudRepository<addtocard,Integer>{

               List<addtocard>  findByCid(int cid);
        
}
