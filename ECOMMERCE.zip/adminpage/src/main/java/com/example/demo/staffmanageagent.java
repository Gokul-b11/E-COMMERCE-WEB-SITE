package com.example.demo;

import org.springframework.data.repository.CrudRepository;

public interface staffmanageagent extends CrudRepository<staffmanage, String> {

}
