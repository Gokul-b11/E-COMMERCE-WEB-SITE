package com.example.demo;

import org.springframework.data.repository.CrudRepository;

public interface staffloginagent extends CrudRepository<stafflogin, String> {

}
