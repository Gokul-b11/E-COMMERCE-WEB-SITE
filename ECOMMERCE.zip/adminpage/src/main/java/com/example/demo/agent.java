package com.example.demo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

public interface agent extends CrudRepository<productsentity , String>{
	List<productsentity> findByCategoryContaining(String substring);
	List<productsentity>  findByCategory(String category);
	productsentity  findById(long id);


}