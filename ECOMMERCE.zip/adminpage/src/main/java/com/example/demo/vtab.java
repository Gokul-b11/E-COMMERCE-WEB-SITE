package com.example.demo;

import jakarta.persistence.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class vtab {
@Id

String name;
String mail;
String pass;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getMail() {
	return mail;
}
public void setMail(String mail) {
	this.mail = mail;
}
public String getPass() {
	return pass;
}
public void setPass(String pass) {
	this.pass = pass;
}



}
