package com.example.demo;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class addtocard {
        @Id
         @GeneratedValue(strategy = GenerationType.IDENTITY)
        int id;
        int cid;
        long  pid;
        String name;

String category;

Double oldprize;
Double newprize;


int discount;


public int getId() {
        return id;
}


public void setId(int id) {
        this.id = id;
}


public int getCid() {
        return cid;
}


public void setCid(int cid) {
        this.cid = cid;
}


public long getPid() {
        return pid;
}


public void setPid(long pid) {
        this.pid = pid;
}


public String getName() {
        return name;
}


public void setName(String name) {
        this.name = name;
}


public String getCategory() {
        return category;
}


public void setCategory(String category) {
        this.category = category;
}


public Double getOldprize() {
        return oldprize;
}


public void setOldprize(Double oldprize) {
        this.oldprize = oldprize;
}


public Double getNewprize() {
        return newprize;
}


public void setNewprize(Double newprize) {
        this.newprize = newprize;
}


public int getDiscount() {
        return discount;
}


public void setDiscount(int discount) {
        this.discount = discount;
}


}
