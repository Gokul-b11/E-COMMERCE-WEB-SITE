package com.example.demo;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class productsentity {

String name;
String des;
String category;
LocalDate startDate;
LocalDate expDate;
Double oldprize;
Double newprize;
@Column(nullable =true)
String filepath;
@Id
 @GeneratedValue(strategy = GenerationType.IDENTITY)
long id;

public long getId() {
	return id;
}
public void setId(long id) {
	this.id = id;
}
public String getFilepath() {
	return filepath;
}
public void setFilepath(String filepath) {
	this.filepath = filepath;
}
int discount;
public Double getNewprize() {
	return newprize;
}
public void setNewprize(Double newprize) {
	this.newprize = newprize;
}

public int getDiscount() {
	return discount;
}
public void setDiscount(int discount) {
	this.discount = discount;
}
boolean freedelivery;
public boolean isFreedelivery() {
	return freedelivery;
}
public void setFreedelivery(boolean freedelivery) {
	this.freedelivery = freedelivery;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getDes() {
	return des;
}
public void setDes(String des) {
	this.des = des;
}
public String getCategory() {
	return category;
}
public void setCategory(String category) {
	this.category = category;
}
public LocalDate getStartDate() {
	return startDate;
}
public void setStartDate(LocalDate startDate) {
	this.startDate = startDate;
}
public LocalDate getExpDate() {
	return expDate;
}
public void setExpDate(LocalDate expDate) {
	this.expDate = expDate;
}

public Double getOldprize() {
	return oldprize;
}
public void setOldprize(Double oldprize) {
	this.oldprize = oldprize;
}




}
