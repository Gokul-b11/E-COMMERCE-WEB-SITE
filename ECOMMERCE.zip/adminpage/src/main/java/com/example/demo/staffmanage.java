package com.example.demo;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class staffmanage {
	@Id
	String name;
	String des;
	String category;
	LocalDate startDate;
	LocalDate expDate;
	Boolean freedelivery;
	Double oldprize;
	Double newprize;
	String imgUrl;

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDes() {
		return des;
	}
	public void setDes(String des) {
		this.des = des;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public LocalDate getStartDate() {
		return startDate;
	}
	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}
	public LocalDate getExpDate() {
		return expDate;
	}
	public void setExpDate(LocalDate expDate) {
		this.expDate = expDate;
	}
	public Boolean getFreedelivery() {
		return freedelivery;
	}
	public void setFreedelivery(Boolean freedelivery) {
		this.freedelivery = freedelivery;
	}
	public Double getOldprize() {
		return oldprize;
	}
	public void setOldprize(Double oldprize) {
		this.oldprize = oldprize;
	}
	public Double getNewprize() {
		return newprize;
	}
	public void setNewprize(Double newprize) {
		this.newprize = newprize;
	}
	public String getImgUrl() {
		return imgUrl;
	}
	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}
	
	

}
